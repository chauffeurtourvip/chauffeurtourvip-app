// ============================================================
//  RÉGLAGES DE TON APPLI — c'est le seul fichier à modifier
// ============================================================

// 1) Clés Firebase : console.firebase.google.com > Paramètres du projet > Vos applications > Web
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyDVdZF2FLMb4fghY3G5OYL4I3e0rp8RuX0',
  authDomain: 'chauffeurtourvip-c7309.firebaseapp.com',
  projectId: 'chauffeurtourvip-c7309',
  storageBucket: 'chauffeurtourvip-c7309.firebasestorage.app',
  messagingSenderId: '155009954826',
  appId: '1:155009954826:web:7c985d9407366e1ba35bf3',
};

// 2) Clé Google Maps Platform (la même que dans app.json)
//    APIs à activer : Maps SDK for Android, Places API (New), Routes API
export const GOOGLE_API_KEY = 'AIzaSyBJzDxsb0ubLgeBkHuHjFMTaeUPyztykM4';

// 3) Le compte chauffeur : l'e-mail avec lequel TOI tu te connectes.
//    Ce compte voit le « Mode chauffeur ». Mets le même e-mail dans firestore.rules.
export const DRIVER_EMAIL = 'lamtalssiyoussef@gmail.com';

export const COMPANY = {
  name: 'ChauffeurTourVIP',
  phone: '+33600000000', // ton numéro, affiché aux clients
  website: 'https://réservationvtc.com',
  privacyUrl: 'https://réservationvtc.com/confidentialite', // obligatoire pour le Play Store
};

// 4) Tes tarifs. prix = max(minimum, priseEnCharge + km × prixKm) × majoration nuit
export const VEHICLES = [
  { id: 'berline', name: 'Berline', model: 'Tesla Model Y ou similaire', seats: 4, bags: 3, desc: 'Confort, jusqu\'à 4 passagers', equip: ['Wi-Fi', 'Eau', 'Chargeurs'], base: 5, perKm: 2.0, min: 25, minHub: 30 },
  { id: 'van', name: 'Van', model: 'Mercedes Classe V ou similaire', seats: 7, bags: 7, desc: 'Familles, groupes et bagages', equip: ['Wi-Fi', 'Eau', 'Grand coffre'], base: 5, perKm: 3.0, min: 50, minHub: 50 },
];

// Gares et aéroports des grandes villes : minimum de course spécial (minHub)
export const HUBS = [
  { name: 'Aéroport Montpellier', lat: 43.5783, lng: 3.9630 },
  { name: 'Gare Montpellier Saint-Roch', lat: 43.6047, lng: 3.8807 },
  { name: 'Gare Montpellier Sud de France', lat: 43.5950, lng: 3.9222 },
  { name: 'Gare de Nîmes', lat: 43.8327, lng: 4.3659 },
  { name: 'Gare Nîmes Pont-du-Gard', lat: 43.7891, lng: 4.4069 },
  { name: 'Aéroport Nîmes-Garons', lat: 43.7574, lng: 4.4163 },
  { name: 'Gare Avignon TGV', lat: 43.9216, lng: 4.7862 },
  { name: 'Gare Avignon Centre', lat: 43.9419, lng: 4.8059 },
  { name: 'Aéroport Marseille', lat: 43.4367, lng: 5.2150 },
  { name: 'Gare Marseille Saint-Charles', lat: 43.3027, lng: 5.3806 },
];
export const NIGHT = { from: 21, to: 7, factor: 1 }; // majoration de nuit : 1 = aucune, 1.2 = +20 %

// Lieux proposés en raccourci dans la recherche d'adresse
export const FAVORITES = [
  { address: 'Aéroport Montpellier Méditerranée', lat: 43.5783, lng: 3.9630 },
  { address: 'Gare Montpellier Saint-Roch', lat: 43.6047, lng: 3.8807 },
  { address: 'Gare de Nîmes', lat: 43.8327, lng: 4.3659 },
  { address: 'Aéroport Nîmes-Garons', lat: 43.7574, lng: 4.4163 },
  { address: 'Aigues-Mortes, remparts', lat: 43.5667, lng: 4.1925 },
  { address: 'Le Grau-du-Roi, centre', lat: 43.5366, lng: 4.1367 },
  { address: "Plage de l'Espiguette", lat: 43.4923, lng: 4.1430 },
  { address: 'Gare Avignon TGV', lat: 43.9216, lng: 4.7862 },
];

// Centre de la carte au démarrage (Le Grau-du-Roi)
export const MAP_CENTER = { latitude: 43.55, longitude: 4.15, latitudeDelta: 0.35, longitudeDelta: 0.35 };

function nearHub(p) {
  if (!p) return false;
  return HUBS.some((h) => {
    const dLat = (h.lat - p.lat) * 111, dLng = (h.lng - p.lng) * 111 * Math.cos((p.lat * Math.PI) / 180);
    return Math.sqrt(dLat * dLat + dLng * dLng) < 1.2; // moins de 1,2 km
  });
}
export function isHubTrip(pickup, dropoff) { return nearHub(pickup) || nearHub(dropoff); }

export function priceFor(vehicle, km, date, pickup, dropoff) {
  if (km == null) return null;
  const h = date ? date.getHours() : new Date().getHours();
  const night = h >= NIGHT.from || h < NIGHT.to;
  const min = isHubTrip(pickup, dropoff) ? vehicle.minHub : vehicle.min;
  return Math.round(Math.max(min, vehicle.base + vehicle.perKm * km) * (night ? NIGHT.factor : 1));
}

// Prix total : aller (+ retour si aller-retour, au tarif de l'heure du retour)
export function totalPrice(vehicle, km, when, roundTrip, returnAt, pickup, dropoff) {
  const out = priceFor(vehicle, km, when || new Date(), pickup, dropoff);
  if (out == null) return null;
  return roundTrip ? out + priceFor(vehicle, km, returnAt || when || new Date(), dropoff, pickup) : out;
}
