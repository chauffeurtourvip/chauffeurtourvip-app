import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Linking } from 'react-native';
import { deleteUser, signOut, updateProfile } from 'firebase/auth';
import { deleteDoc, doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { useApp } from '../store';
import { COMPANY } from '../config';
import { C, s } from '../theme';

export default function ProfileScreen() {
  const { user, profile } = useApp();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [msg, setMsg] = useState('');
  const [sure, setSure] = useState(false);

  useEffect(() => { setName(profile?.name || user.displayName || ''); setPhone(profile?.phone || ''); }, [profile?.name, profile?.phone]);

  async function save() {
    try {
      await setDoc(doc(db, 'users', user.uid), { name: name.trim(), phone: phone.trim(), email: user.email }, { merge: true });
      await updateProfile(user, { displayName: name.trim() });
      setMsg('Profil enregistré ✓');
    } catch (e) { setMsg(e.message); }
  }

  // Obligatoire sur le Play Store : suppression du compte depuis l'appli
  async function remove() {
    if (!sure) { setSure(true); return; }
    try {
      await deleteDoc(doc(db, 'users', user.uid));
      await deleteUser(user);
    } catch (e) {
      setMsg(e.code === 'auth/requires-recent-login' ? 'Par sécurité, déconnectez-vous puis reconnectez-vous avant de supprimer votre compte.' : e.message);
    }
  }

  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <View style={s.field}><Text style={s.label}>Nom</Text><TextInput style={s.input} value={name} onChangeText={setName} /></View>
      <View style={s.field}><Text style={s.label}>Téléphone</Text><TextInput style={s.input} value={phone} onChangeText={setPhone} keyboardType="phone-pad" /></View>
      <View style={s.field}><Text style={s.label}>E-mail</Text><Text style={[s.input, { color: C.mut }]}>{user.email}</Text></View>
      {!!msg && <Text style={[s.mut, { marginTop: 10 }]}>{msg}</Text>}
      <Pressable style={[s.blackBtn, { marginTop: 18 }]} onPress={save}><Text style={s.blackTxt}>Enregistrer</Text></Pressable>
      <Pressable style={[s.ghostBtn, { marginTop: 12 }]} onPress={() => signOut(auth)}><Text style={s.ghostTxt}>Déconnexion</Text></Pressable>
      <Pressable style={{ padding: 14, alignItems: 'center' }} onPress={() => Linking.openURL(COMPANY.privacyUrl)}><Text style={{ textDecorationLine: 'underline' }}>Politique de confidentialité</Text></Pressable>
      <Pressable style={{ padding: 14, alignItems: 'center' }} onPress={remove}><Text style={{ color: C.pink }}>{sure ? 'Confirmer : supprimer définitivement mon compte' : 'Supprimer mon compte'}</Text></Pressable>
    </ScrollView>
  );
}
