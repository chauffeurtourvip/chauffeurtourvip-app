import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, FlatList, ActivityIndicator } from 'react-native';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import { useApp } from '../store';
import { C, s, STATUS, fmtDate } from '../theme';

export default function HistoryScreen({ navigation }) {
  const { user } = useApp();
  const [list, setList] = useState(null);

  useEffect(() => {
    const q = query(collection(db, 'rides'), where('clientId', '==', user.uid));
    return onSnapshot(q, (snap) => {
      const l = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      l.sort((a, b) => (b.date?.seconds || 0) - (a.date?.seconds || 0));
      setList(l);
    }, () => setList([]));
  }, [user.uid]);

  if (!list) return <ActivityIndicator style={{ flex: 1 }} color={C.ink} />;
  return (
    <FlatList
      style={{ backgroundColor: C.bg }}
      contentContainerStyle={{ padding: 12 }}
      data={list}
      keyExtractor={(r) => r.id}
      ListEmptyComponent={
        <View style={{ alignItems: 'center', padding: 40 }}>
          <Text style={s.mut}>Aucune réservation pour l'instant.</Text>
          <Pressable style={[s.accentBtn, { marginTop: 16, alignSelf: 'stretch' }]} onPress={() => navigation.goBack()}><Text style={s.accentTxt}>Réserver une course</Text></Pressable>
        </View>
      }
      renderItem={({ item: r }) => (
        <Pressable style={s.card} onPress={() => navigation.navigate('Ride', { id: r.id })}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <Text style={{ fontWeight: '700' }}>{fmtDate(r.date)}</Text>
            <Text style={{ fontWeight: '700' }}>{r.price} €</Text>
          </View>
          <Text style={s.mut} numberOfLines={1}>{r.pickup.address}</Text>
          <Text style={s.mut} numberOfLines={1}>→ {r.dropoff.address}</Text>
          <Text style={{ color: STATUS[r.status]?.color, fontWeight: '600', marginTop: 4 }}>{STATUS[r.status]?.label} · {r.vehicle}</Text>
        </Pressable>
      )}
    />
  );
}
