import React from 'react';
import { View, Text, Pressable, Platform, Image } from 'react-native';
import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { C, s } from './theme';

export { Ionicons, MaterialCommunityIcons };

// Pastille départ (rond) / arrivée (carré), comme les grandes applis VTC
export function Pin({ kind = 'from', size = 12 }) {
  return kind === 'from'
    ? <View style={{ width: size, height: size, borderRadius: size / 2, borderWidth: 3, borderColor: C.blue, backgroundColor: C.white }} />
    : <View style={{ width: size, height: size, borderRadius: 3, backgroundColor: C.red }} />;
}

// Repère sur la carte
export function MapPin({ kind = 'from' }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={{ backgroundColor: kind === 'from' ? C.blue : C.red, padding: 7, borderRadius: 20, borderWidth: 3, borderColor: C.white, ...s.shadow }}>
        <Ionicons name={kind === 'from' ? 'person' : 'flag'} size={14} color={C.white} />
      </View>
    </View>
  );
}

export function CarMarker() {
  return (
    <View style={{ backgroundColor: C.black, padding: 6, borderRadius: 18, borderWidth: 2, borderColor: C.white }}>
      <Ionicons name="car-sport" size={18} color={C.white} />
    </View>
  );
}

export function Btn({ title, icon, onPress, variant = 'black', disabled, style }) {
  const base = variant === 'accent' ? s.accentBtn : variant === 'ghost' ? s.ghostBtn : s.blackBtn;
  const txt = variant === 'accent' ? s.accentTxt : variant === 'ghost' ? s.ghostTxt : s.blackTxt;
  const col = variant === 'ghost' ? C.ink : C.white;
  return (
    <Pressable onPress={onPress} disabled={disabled}
      style={({ pressed }) => [base, { opacity: disabled ? 0.5 : pressed ? 0.85 : 1, transform: [{ scale: pressed ? 0.98 : 1 }] }, style]}>
      {icon && <Ionicons name={icon} size={20} color={col} />}
      <Text style={txt}>{title}</Text>
    </Pressable>
  );
}

// Icône de véhicule par catégorie
export function VehicleIcon({ id, size = 34, color = C.ink }) {
  const name = { berline: 'car-side', van: 'van-passenger' }[id] || 'car-side';
  return <MaterialCommunityIcons name={name} size={size} color={color} />;
}

export function Logo({ dark = false, size = 'md' }) {
  const big = size === 'lg';
  const w = big ? 240 : 150;
  return (
    <View style={{ alignItems: 'center' }}>
      <Image source={dark ? require('../assets/logo-white.png') : require('../assets/logo-black.png')} style={{ width: w, height: w * 345 / 585 }} resizeMode="contain" />
      <Text style={{ marginTop: 10, fontSize: big ? 26 : 18, fontWeight: '800', letterSpacing: 0.5, color: dark ? C.white : C.ink }}>
        Chauffeur<Text style={{ color: C.pink }}>Tour</Text>VIP
      </Text>
    </View>
  );
}

export function pickDateTime(current, onPick, setIos) {
  if (Platform.OS === 'android') {
    DateTimePickerAndroid.open({
      value: current || new Date(), mode: 'date', minimumDate: new Date(),
      onChange: (e, d) => {
        if (e.type !== 'set' || !d) return;
        DateTimePickerAndroid.open({ value: d, mode: 'time', is24Hour: true, onChange: (e2, t) => { if (e2.type === 'set' && t) onPick(t); } });
      },
    });
  } else setIos(true);
}
