import { GOOGLE_API_KEY } from './config';

// Suggestions d'adresses (Places API New)
export async function autocomplete(input, near, sessionToken) {
  if (!input || input.length < 3) return [];
  const body = { input, languageCode: 'fr', includedRegionCodes: ['fr'], sessionToken };
  if (near) body.locationBias = { circle: { center: { latitude: near.lat, longitude: near.lng }, radius: 50000 } };
  const r = await fetch('https://places.googleapis.com/v1/places:autocomplete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': GOOGLE_API_KEY },
    body: JSON.stringify(body),
  });
  const j = await r.json();
  if (j.error) throw new Error(j.error.message);
  return (j.suggestions || [])
    .filter((s) => s.placePrediction)
    .map((s) => ({
      id: s.placePrediction.placeId,
      main: s.placePrediction.structuredFormat?.mainText?.text || s.placePrediction.text.text,
      sub: s.placePrediction.structuredFormat?.secondaryText?.text || '',
      text: s.placePrediction.text.text,
    }));
}

export async function placeDetails(placeId, sessionToken) {
  const r = await fetch(
    `https://places.googleapis.com/v1/places/${placeId}?languageCode=fr${sessionToken ? '&sessionToken=' + sessionToken : ''}`,
    { headers: { 'X-Goog-Api-Key': GOOGLE_API_KEY, 'X-Goog-FieldMask': 'location,formattedAddress,displayName' } }
  );
  const j = await r.json();
  if (j.error) throw new Error(j.error.message);
  return { address: j.formattedAddress || j.displayName?.text, lat: j.location.latitude, lng: j.location.longitude };
}

// Itinéraire réel en voiture (Routes API) : distance, durée, tracé
export async function route(from, to) {
  const r = await fetch('https://routes.googleapis.com/directions/v2:computeRoutes', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': GOOGLE_API_KEY,
      'X-Goog-FieldMask': 'routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline',
    },
    body: JSON.stringify({
      origin: { location: { latLng: { latitude: from.lat, longitude: from.lng } } },
      destination: { location: { latLng: { latitude: to.lat, longitude: to.lng } } },
      travelMode: 'DRIVE',
      routingPreference: 'TRAFFIC_UNAWARE',
      languageCode: 'fr-FR',
    }),
  });
  const j = await r.json();
  if (j.error) throw new Error(j.error.message);
  const rt = j.routes?.[0];
  if (!rt) throw new Error('Itinéraire introuvable');
  return {
    km: rt.distanceMeters / 1000,
    min: Math.round(parseInt(rt.duration, 10) / 60),
    polyline: rt.polyline.encodedPolyline,
  };
}

export function decodePolyline(str) {
  let index = 0, lat = 0, lng = 0;
  const pts = [];
  while (index < str.length) {
    let b, shift = 0, result = 0;
    do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lat += result & 1 ? ~(result >> 1) : result >> 1;
    shift = 0; result = 0;
    do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
    lng += result & 1 ? ~(result >> 1) : result >> 1;
    pts.push({ latitude: lat / 1e5, longitude: lng / 1e5 });
  }
  return pts;
}

export function newSessionToken() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}
