import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { C } from '../theme';
import { Logo, Ionicons } from '../ui';

const ERR = {
  'auth/invalid-email': 'Adresse e-mail invalide.',
  'auth/invalid-credential': 'E-mail ou mot de passe incorrect.',
  'auth/wrong-password': 'Mot de passe incorrect.',
  'auth/user-not-found': 'Aucun compte avec cet e-mail.',
  'auth/email-already-in-use': 'Un compte existe déjà avec cet e-mail. Connectez-vous.',
  'auth/weak-password': 'Le mot de passe doit faire au moins 6 caractères.',
  'auth/network-request-failed': 'Pas de connexion internet.',
  'auth/too-many-requests': 'Trop de tentatives, réessayez dans quelques minutes.',
};

function Field({ icon, right, ...p }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 14, paddingHorizontal: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)' }}>
      <Ionicons name={icon} size={20} color="#fff" />
      <TextInput placeholderTextColor="rgba(255,255,255,0.55)" style={{ flex: 1, color: '#fff', fontSize: 16, paddingVertical: 14, paddingHorizontal: 12 }} {...p} />
      {right}
    </View>
  );
}

export default function AuthScreen() {
  const ins = useSafeAreaInsets();
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [pwd, setPwd] = useState('');
  const [show, setShow] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    setMsg('');
    if (mode === 'signup' && (!name.trim() || phone.replace(/\D/g, '').length < 9)) {
      setMsg('Indiquez votre nom et un numéro de téléphone valide.');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), pwd);
      } else {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), pwd);
        await updateProfile(cred.user, { displayName: name.trim() });
        await setDoc(doc(db, 'users', cred.user.uid), {
          name: name.trim(), phone: phone.trim(), email: email.trim(), createdAt: serverTimestamp(),
        }, { merge: true });
      }
    } catch (e) {
      setMsg(ERR[e.code] || e.message);
    }
    setBusy(false);
  }

  async function forgot() {
    if (!email.trim()) { setMsg('Entrez votre e-mail puis touchez « Mot de passe oublié ».'); return; }
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setMsg('Un e-mail de réinitialisation vous a été envoyé.');
    } catch (e) { setMsg(ERR[e.code] || e.message); }
  }

  return (
    <LinearGradient colors={['#1a1a22', '#0b0b0d', '#0b0b0d']} style={{ flex: 1 }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 24, paddingTop: ins.top + 50, paddingBottom: ins.bottom + 24 }} keyboardShouldPersistTaps="handled">
          <Logo dark size="lg" />
          <Text style={{ color: 'rgba(255,255,255,0.7)', textAlign: 'center', marginTop: 8, fontSize: 15 }}>Votre chauffeur privé en Camargue</Text>

          <View style={{ flexDirection: 'row', backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 14, padding: 4, marginTop: 40, marginBottom: 20 }}>
            {[['login', 'Connexion'], ['signup', 'Inscription']].map(([k, t]) => (
              <Pressable key={k} onPress={() => { setMode(k); setMsg(''); }} style={{ flex: 1, paddingVertical: 12, borderRadius: 11, alignItems: 'center', backgroundColor: mode === k ? C.white : 'transparent' }}>
                <Text style={{ fontWeight: '700', color: mode === k ? C.black : 'rgba(255,255,255,0.75)' }}>{t}</Text>
              </Pressable>
            ))}
          </View>

          {mode === 'signup' && (
            <>
              <Field icon="person-outline" placeholder="Prénom et nom" value={name} onChangeText={setName} autoComplete="name" />
              <Field icon="call-outline" placeholder="Téléphone" value={phone} onChangeText={setPhone} keyboardType="phone-pad" autoComplete="tel" />
            </>
          )}
          <Field icon="mail-outline" placeholder="E-mail" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoComplete="email" />
          <Field icon="lock-closed-outline" placeholder="Mot de passe" value={pwd} onChangeText={setPwd} secureTextEntry={!show} autoCapitalize="none"
            right={<Pressable onPress={() => setShow(!show)} hitSlop={12}><Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={20} color="rgba(255,255,255,0.7)" /></Pressable>} />

          {!!msg && <Text style={{ color: '#f3c7cf', marginBottom: 12, fontSize: 14 }}>{msg}</Text>}

          <Pressable onPress={submit} disabled={busy} style={({ pressed }) => ({ backgroundColor: C.pink, borderRadius: 14, minHeight: 56, alignItems: 'center', justifyContent: 'center', marginTop: 6, opacity: pressed ? 0.85 : 1 })}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={{ color: '#fff', fontSize: 17, fontWeight: '800' }}>{mode === 'login' ? 'Se connecter' : 'Créer mon compte'}</Text>}
          </Pressable>

          {mode === 'login' && (
            <Pressable onPress={forgot} style={{ padding: 14, alignItems: 'center' }}>
              <Text style={{ color: 'rgba(255,255,255,0.75)' }}>Mot de passe oublié ?</Text>
            </Pressable>
          )}
          <View style={{ flex: 1 }} />
          <Text style={{ color: 'rgba(255,255,255,0.4)', textAlign: 'center', fontSize: 12, marginTop: 24 }}>Transferts aéroport et gare · Excursions · Événements</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}
