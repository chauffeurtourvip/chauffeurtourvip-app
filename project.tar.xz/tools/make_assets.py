# Génère toutes les images de l'appli à partir de tools/logo-src.png
from PIL import Image
src = Image.open('tools/logo-src.png').convert('RGBA')
alpha = src.split()[3]
w, h = src.size

def tinted(rgb):
    im = Image.new('RGBA', (w, h), rgb + (0,)); im.putalpha(alpha); return im

def square(img, size, frac, bg=(0, 0, 0, 0)):
    c = Image.new('RGBA', (size, size), bg)
    nw = int(size * frac); nh = int(h * nw / w)
    r = img.resize((nw, nh), Image.LANCZOS)
    c.alpha_composite(r, ((size - nw) // 2, (size - nh) // 2)); return c

black, white = tinted((17, 17, 19)), tinted((255, 255, 255))
black.resize((w, h)).save('assets/logo-black.png')
white.resize((w, h)).save('assets/logo-white.png')
square(black, 1024, 0.82, (255, 255, 255, 255)).convert('RGB').save('assets/icon.png')
square(black, 1024, 0.62).save('assets/android-icon-foreground.png')
square(black, 1024, 0.62).save('assets/android-icon-monochrome.png')
square(black, 1024, 0.7).save('assets/splash-icon.png')
square(black, 64, 0.9, (255, 255, 255, 255)).save('assets/favicon.png')
print('images OK')
