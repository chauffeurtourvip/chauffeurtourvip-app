import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, FlatList, TextInput, ActivityIndicator } from 'react-native';
import { collection, doc, onSnapshot, query, setDoc, where } from 'firebase/firestore';
import { db } from '../firebase';
import { C, s, STATUS, fmtDate } from '../theme';

const TABS = [
  { id: 'new', t: 'Nouvelles', st: ['pending'] },
  { id: 'todo', t: 'À venir', st: ['accepted', 'enroute', 'arrived', 'onboard'] },
  { id: 'old', t: 'Historique', st: ['done', 'cancelled', 'refused'] },
];

export default function DriverScreen({ navigation }) {
  const [tab, setTab] = useState('new');
  const [rides, setRides] = useState(null);
  const [me, setMe] = useState({ name: '', phone: '', car: '' });
  const [edit, setEdit] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => {
    // 60 derniers jours + futur
    const since = new Date(Date.now() - 60 * 86400000);
    const q = query(collection(db, 'rides'), where('date', '>=', since));
    return onSnapshot(q, (snap) => setRides(snap.docs.map((d) => ({ id: d.id, ...d.data() }))), (e) => { setErr(e.message); setRides([]); });
  }, []);
  useEffect(() => onSnapshot(doc(db, 'settings', 'driver'), (d) => d.exists() && setMe((m) => ({ ...m, ...d.data() }))), []);

  if (!rides) return <ActivityIndicator style={{ flex: 1 }} color={C.ink} />;

  const T = TABS.find((x) => x.id === tab);
  const list = rides.filter((r) => T.st.includes(r.status)).sort((a, b) => tab === 'old' ? b.date.seconds - a.date.seconds : a.date.seconds - b.date.seconds);
  const now = new Date();
  const monthDone = rides.filter((r) => r.status === 'done' && r.date.toDate().getMonth() === now.getMonth() && r.date.toDate().getFullYear() === now.getFullYear());
  const today = rides.filter((r) => ['accepted', 'enroute', 'arrived', 'onboard'].includes(r.status) && r.date.toDate().toDateString() === now.toDateString());

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <View style={{ flexDirection: 'row', padding: 12, gap: 10 }}>
        <Stat n={rides.filter((r) => r.status === 'pending').length} t="à confirmer" c={C.pink} />
        <Stat n={today.length} t="aujourd'hui" c={C.blue} />
        <Stat n={monthDone.reduce((a, r) => a + (r.price || 0), 0) + ' €'} t="ce mois" c={C.black} />
      </View>

      <Pressable onPress={() => setEdit(!edit)} style={{ paddingHorizontal: 14, paddingBottom: 8 }}>
        <Text style={{ textDecorationLine: 'underline' }}>{edit ? 'Fermer' : 'Mes infos affichées aux clients'}</Text>
      </Pressable>
      {edit && (
        <View style={[s.card, { marginHorizontal: 12 }]}>
          {[['name', 'Nom affiché'], ['phone', 'Téléphone'], ['car', 'Véhicule (modèle, couleur, plaque)']].map(([k, l]) => (
            <View key={k} style={s.field}><Text style={s.label}>{l}</Text><TextInput style={s.input} value={me[k] || ''} onChangeText={(v) => setMe({ ...me, [k]: v })} /></View>
          ))}
          <Pressable style={[s.blackBtn, { marginTop: 12 }]} onPress={async () => { await setDoc(doc(db, 'settings', 'driver'), { name: me.name || '', phone: me.phone || '', car: me.car || '' }, { merge: true }); setEdit(false); }}>
            <Text style={s.blackTxt}>Enregistrer</Text>
          </Pressable>
        </View>
      )}

      <View style={{ flexDirection: 'row', marginHorizontal: 12, backgroundColor: '#fff', borderRadius: 8, overflow: 'hidden' }}>
        {TABS.map((x) => (
          <Pressable key={x.id} onPress={() => setTab(x.id)} style={{ flex: 1, padding: 12, alignItems: 'center', backgroundColor: tab === x.id ? C.black : '#fff' }}>
            <Text style={{ color: tab === x.id ? '#fff' : C.ink, fontWeight: '600' }}>{x.t}</Text>
          </Pressable>
        ))}
      </View>
      {!!err && <Text style={[s.err, { paddingHorizontal: 14 }]}>{err}</Text>}

      <FlatList
        contentContainerStyle={{ padding: 12 }}
        data={list}
        keyExtractor={(r) => r.id}
        ListEmptyComponent={<Text style={[s.mut, { textAlign: 'center', padding: 30 }]}>Rien ici pour l'instant.</Text>}
        renderItem={({ item: r }) => (
          <Pressable style={[s.card, r.status === 'pending' && { borderLeftWidth: 5, borderLeftColor: C.pink }]} onPress={() => navigation.navigate('DriverRide', { id: r.id })}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ fontWeight: '700', fontSize: 16 }}>{fmtDate(r.date)}</Text>
              <Text style={{ fontWeight: '700', fontSize: 16 }}>{r.price} €</Text>
            </View>
            <Text numberOfLines={1}>{r.pickup.address}</Text>
            <Text numberOfLines={1} style={s.mut}>→ {r.dropoff.address}</Text>
            <Text style={[s.mut, { marginTop: 4 }]}>{r.roundTrip ? 'A/R · ' : ''}{r.clientName} · {r.vehicle} · {r.pax} pass.{r.bags ? ` · ${r.bags} bag.` : ''}</Text>
            <Text style={{ color: STATUS[r.status]?.color, fontWeight: '600', marginTop: 2 }}>{STATUS[r.status]?.label}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}

function Stat({ n, t, c }) {
  return (
    <View style={{ flex: 1, backgroundColor: '#fff', borderRadius: 10, padding: 10, alignItems: 'center', borderTopWidth: 4, borderTopColor: c }}>
      <Text style={{ fontSize: 20, fontWeight: '700' }}>{n}</Text>
      <Text style={s.mut}>{t}</Text>
    </View>
  );
}
