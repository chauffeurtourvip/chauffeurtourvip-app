import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, Switch, ActivityIndicator, StyleSheet } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { addDoc, collection, doc, getDoc, serverTimestamp, Timestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { useApp } from '../store';
import { VEHICLES, priceFor, totalPrice } from '../config';
import { sendPush } from '../push';
import { C, s, fmtDate } from '../theme';
import { Pin, Ionicons, VehicleIcon, pickDateTime } from '../ui';

const PAY = [
  { id: 'card', t: 'Carte à bord', icon: 'card-outline' },
  { id: 'cash', t: 'Espèces', icon: 'cash-outline' },
  { id: 'invoice', t: 'Sur facture', icon: 'document-text-outline' },
];
const OPTS = [
  { t: 'Animal', icon: 'paw-outline' },
  { t: 'Vélo / gros bagage', icon: 'bicycle-outline' },
];
const AGES = ['< 1 an', '1 an', '2 ans', '3 ans', '4 ans', '5 ans', '6 ans', '7 ans', '8 ans', '9 ans', '10 ans'];

function Stepper({ label, icon, value, setValue, min = 0, max }) {
  return (
    <View style={st.stepRow}>
      <Ionicons name={icon} size={20} color={C.ink} />
      <Text style={{ flex: 1, fontSize: 16 }}>{label}</Text>
      <Pressable style={st.stepBtn} onPress={() => setValue(Math.max(min, value - 1))} accessibilityLabel={`Moins de ${label}`}>
        <Ionicons name="remove" size={20} color={value <= min ? C.mut : C.ink} />
      </Pressable>
      <Text style={{ width: 30, textAlign: 'center', fontSize: 18, fontWeight: '700' }}>{value}</Text>
      <Pressable style={st.stepBtn} onPress={() => setValue(Math.min(max, value + 1))} accessibilityLabel={`Plus de ${label}`}>
        <Ionicons name="add" size={20} color={value >= max ? C.mut : C.ink} />
      </Pressable>
    </View>
  );
}

export default function BookScreen({ navigation }) {
  const ins = useSafeAreaInsets();
  const { user, profile, pickup, dropoff, trip, veh, setVeh, when, setWhen, roundTrip, setRoundTrip, returnAt, setReturnAt } = useApp();
  const [iosTarget, setIosTarget] = useState('when');
  const [kids, setKids] = useState([]); // âge de chaque enfant ayant besoin d'un siège
  const [iosPicker, setIosPicker] = useState(false);
  const [pax, setPax] = useState(1);
  const [bags, setBags] = useState(1);
  const [opts, setOpts] = useState([]);
  const [comment, setComment] = useState('');
  const [flight, setFlight] = useState('');
  const [pay, setPay] = useState('card');
  const [other, setOther] = useState(false);
  const [oName, setOName] = useState('');
  const [oPhone, setOPhone] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const km = trip && trip.km != null ? trip.km : null;
  const v = VEHICLES.find((x) => x.id === veh) || VEHICLES[0];
  const date = when || new Date(Date.now() + 15 * 60000);
  const price = totalPrice(v, km, date, roundTrip, returnAt, pickup, dropoff);

  async function submit() {
    setErr('');
    if (!pickup || !dropoff) return setErr('Indiquez le départ et l\'arrivée.');
    if (km == null) return setErr('Itinéraire en cours de calcul, patientez un instant.');
    if (when && when < new Date(Date.now() - 60000)) return setErr('L\'heure choisie est déjà passée.');
    if (pax > v.seats) return setErr(`${v.name} : ${v.seats} passagers maximum. Choisissez le Van.`);
    if (roundTrip && !returnAt) return setErr('Choisissez la date et l\'heure du retour.');
    if (roundTrip && returnAt <= date) return setErr('Le retour doit être après l\'aller.');
    if (kids.some((k) => k == null)) return setErr('Indiquez l\'âge de chaque enfant.');
    if (other && (!oName.trim() || oPhone.replace(/\D/g, '').length < 9)) return setErr('Indiquez le nom et le téléphone du passager.');
    setBusy(true);
    try {
      const ride = {
        clientId: user.uid,
        clientName: profile?.name || user.displayName || '',
        clientPhone: profile?.phone || '',
        clientEmail: user.email,
        clientPushToken: profile?.pushToken || null,
        passenger: other ? { name: oName.trim(), phone: oPhone.trim() } : null,
        pickup, dropoff,
        date: Timestamp.fromDate(date),
        asap: !when,
        vehicle: v.name, vehicleId: v.id, pax, bags,
        roundTrip, returnDate: roundTrip ? Timestamp.fromDate(returnAt) : null,
        childSeats: kids.map((k) => AGES[k]),
        options: opts, comment: comment.trim(), flight: flight.trim(),
        payment: PAY.find((p) => p.id === pay).t,
        price, distanceKm: Math.round(km * 10) / 10, durationMin: trip.min, polyline: trip.polyline,
        source: 'app', status: 'pending', createdAt: serverTimestamp(),
      };
      const ref = await addDoc(collection(db, 'rides'), ride);
      try {
        const d = await getDoc(doc(db, 'settings', 'driver'));
        await sendPush(d.data()?.pushToken, `Nouvelle course${roundTrip ? ' aller-retour' : ''} · ${price} €`, `${when ? fmtDate(date) : 'Dès que possible'} — ${pickup.address} → ${dropoff.address}`, { rideId: ref.id, driver: true });
      } catch {}
      navigation.replace('Ride', { id: ref.id, justBooked: true });
    } catch (e) {
      setErr('Envoi impossible : ' + e.message);
      setBusy(false);
    }
  }

  return (
    <View style={s.screen}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
        {/* Trajet */}
        <View style={s.card}>
          <View style={{ flexDirection: 'row', gap: 12 }}>
            <View style={{ alignItems: 'center', paddingTop: 5 }}>
              <Pin kind="from" /><View style={{ width: 2, flex: 1, backgroundColor: C.line, marginVertical: 3 }} /><Pin kind="to" />
            </View>
            <View style={{ flex: 1, gap: 12 }}>
              <Pressable onPress={() => navigation.navigate('Address', { field: 'pickup' })}><Text style={s.mut}>Départ</Text><Text style={{ fontSize: 15 }} numberOfLines={2}>{pickup?.address}</Text></Pressable>
              <Pressable onPress={() => navigation.navigate('Address', { field: 'dropoff' })}><Text style={s.mut}>Arrivée</Text><Text style={{ fontSize: 15, fontWeight: '600' }} numberOfLines={2}>{dropoff?.address}</Text></Pressable>
            </View>
          </View>
          <View style={st.divider} />
          <View style={st.seg}>
            {[[false, 'Aller simple'], [true, 'Aller-retour']].map(([val, t]) => (
              <Pressable key={t} onPress={() => setRoundTrip(val)} style={[st.segItem, roundTrip === val && { backgroundColor: C.black }]}>
                <Text style={{ fontWeight: '700', color: roundTrip === val ? '#fff' : C.ink }}>{t}</Text>
              </Pressable>
            ))}
          </View>
          <Pressable style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 40 }} onPress={() => { setIosTarget('when'); pickDateTime(when, setWhen, setIosPicker); }}>
            <Ionicons name="calendar-outline" size={20} color={C.blue} />
            <Text style={{ flex: 1, fontSize: 15, fontWeight: '600' }}>Aller : {when ? fmtDate(when) : 'dès que possible'}</Text>
            <Text style={{ color: C.blue, fontWeight: '600' }}>Modifier</Text>
          </Pressable>
          {roundTrip && (
            <Pressable style={{ flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 40 }} onPress={() => { setIosTarget('ret'); pickDateTime(returnAt || date, setReturnAt, setIosPicker); }}>
              <Ionicons name="repeat" size={20} color={returnAt ? C.blue : C.red} />
              <Text style={{ flex: 1, fontSize: 15, fontWeight: '600', color: returnAt ? C.ink : C.red }}>Retour : {returnAt ? fmtDate(returnAt) : 'à choisir'}</Text>
              <Text style={{ color: C.blue, fontWeight: '600' }}>{returnAt ? 'Modifier' : 'Choisir'}</Text>
            </Pressable>
          )}
          {when && <Pressable onPress={() => setWhen(null)} style={{ marginTop: 8 }}><Text style={{ color: C.mut }}>Revenir à « dès que possible »</Text></Pressable>}
          {km != null && <Text style={[s.mut, { marginTop: 8 }]}>{Math.round(km)} km · environ {trip.min} min</Text>}
        </View>
        {iosPicker && <DateTimePicker value={(iosTarget === 'ret' ? returnAt : when) || date} mode="datetime" minimumDate={new Date()} onChange={(e, d) => { setIosPicker(false); if (d) (iosTarget === 'ret' ? setReturnAt : setWhen)(d); }} />}

        {/* Véhicule */}
        <Text style={st.section}>Véhicule</Text>
        {VEHICLES.map((x) => {
          const on = x.id === veh;
          return (
            <Pressable key={x.id} onPress={() => setVeh(x.id)} style={[st.vehRow, on && st.vehRowOn]}>
              <VehicleIcon id={x.id} size={36} color={on ? '#fff' : C.ink} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: '700', fontSize: 16, color: on ? '#fff' : C.ink }}>{x.name}</Text>
                <Text style={{ fontSize: 13, color: on ? '#c8c8d0' : C.mut }} numberOfLines={1}>{x.seats} places · {x.bags} bagages · {x.desc}</Text>
              </View>
              <Text style={{ fontWeight: '800', fontSize: 18, color: on ? C.pink : C.ink }}>{totalPrice(x, km, date, roundTrip, returnAt, pickup, dropoff) ?? '—'} €</Text>
            </Pressable>
          );
        })}

        {/* Passagers */}
        <Text style={st.section}>Passagers et bagages</Text>
        <View style={s.card}>
          <Stepper label="Passagers" icon="people-outline" value={pax} setValue={setPax} min={1} max={8} />
          <View style={st.divider} />
          <Stepper label="Bagages" icon="briefcase-outline" value={bags} setValue={setBags} max={10} />
          <View style={st.divider} />
          <Stepper label="Sièges enfant" icon="happy-outline" value={kids.length} min={0} max={3}
            setValue={(n) => setKids(n > kids.length ? [...kids, null] : kids.slice(0, n))} />
          {kids.map((age, i) => (
            <View key={i} style={{ marginTop: 10 }}>
              <Text style={[s.mut, { marginBottom: 6 }]}>Âge de l'enfant {kids.length > 1 ? i + 1 : ''}</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 6 }}>
                {AGES.map((a, j) => (
                  <Pressable key={a} onPress={() => setKids(kids.map((k, x) => (x === i ? j : k)))} style={[st.age, age === j && st.ageOn]}>
                    <Text style={{ fontWeight: '600', color: age === j ? '#fff' : C.ink }}>{a}</Text>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          ))}
          <View style={st.divider} />
          <View style={st.stepRow}>
            <Ionicons name="person-add-outline" size={20} color={C.ink} />
            <Text style={{ flex: 1, fontSize: 16 }}>Je réserve pour quelqu'un d'autre</Text>
            <Switch value={other} onValueChange={setOther} trackColor={{ true: C.pink }} thumbColor="#fff" />
          </View>
          {other && (
            <View style={{ gap: 8, marginTop: 8 }}>
              <TextInput style={st.input} placeholder="Nom du passager" value={oName} onChangeText={setOName} />
              <TextInput style={st.input} placeholder="Téléphone du passager" keyboardType="phone-pad" value={oPhone} onChangeText={setOPhone} />
            </View>
          )}
        </View>

        {/* Options */}
        <Text style={st.section}>Options</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          {OPTS.map((o) => {
            const on = opts.includes(o.t);
            return (
              <Pressable key={o.t} onPress={() => setOpts(on ? opts.filter((x) => x !== o.t) : [...opts, o.t])} style={[st.chip, on && st.chipOn]}>
                <Ionicons name={on ? 'checkmark' : o.icon} size={16} color={on ? '#fff' : C.ink} />
                <Text style={{ fontWeight: '600', color: on ? '#fff' : C.ink }}>{o.t}</Text>
              </Pressable>
            );
          })}
        </View>
        <View style={[s.card, { marginTop: 12, gap: 8 }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <Ionicons name="airplane-outline" size={20} color={C.blue} />
            <TextInput style={[s.input, { flex: 1 }]} value={flight} onChangeText={setFlight} autoCapitalize="characters" placeholder="N° de vol ou de train (facultatif)" />
          </View>
          <View style={st.divider} />
          <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 10 }}>
            <Ionicons name="chatbubble-ellipses-outline" size={20} color={C.blue} style={{ marginTop: 8 }} />
            <TextInput style={[s.input, { flex: 1 }]} value={comment} onChangeText={setComment} multiline placeholder="Message au chauffeur : code portail, n° d'emplacement camping…" />
          </View>
        </View>

        {/* Paiement */}
        <Text style={st.section}>Paiement</Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {PAY.map((p) => {
            const on = pay === p.id;
            return (
              <Pressable key={p.id} onPress={() => setPay(p.id)} style={[st.pay, on && { borderColor: C.black, backgroundColor: '#fff' }]}>
                <Ionicons name={p.icon} size={24} color={on ? C.black : C.mut} />
                <Text style={{ fontSize: 13, fontWeight: '600', color: on ? C.black : C.mut, textAlign: 'center' }}>{p.t}</Text>
              </Pressable>
            );
          })}
        </View>
        {!!err && <Text style={[s.err, { marginTop: 12 }]}>{err}</Text>}
      </ScrollView>

      {/* Barre de validation */}
      <View style={[st.bottom, { paddingBottom: ins.bottom + 12 }]}>
        <View>
          <Text style={s.mut}>{roundTrip ? 'Aller-retour garanti' : 'Prix garanti'}</Text>
          <Text style={{ fontSize: 26, fontWeight: '800' }}>{price != null ? price + ' €' : '—'}</Text>
        </View>
        <Pressable onPress={submit} disabled={busy} style={({ pressed }) => [s.accentBtn, { flex: 1, opacity: pressed ? 0.85 : 1 }]}>
          {busy ? <ActivityIndicator color="#fff" /> : <><Ionicons name="checkmark-circle" size={22} color="#fff" /><Text style={s.accentTxt}>Confirmer</Text></>}
        </Pressable>
      </View>
    </View>
  );
}

const st = StyleSheet.create({
  section: { fontSize: 17, fontWeight: '700', marginTop: 18, marginBottom: 10, color: C.ink },
  divider: { height: 1, backgroundColor: C.line, marginVertical: 12 },
  stepRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 44 },
  stepBtn: { width: 40, height: 40, borderRadius: 20, borderWidth: 1.5, borderColor: C.line, alignItems: 'center', justifyContent: 'center' },
  input: { backgroundColor: C.bg, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16 },
  vehRow: { flexDirection: 'row', alignItems: 'center', gap: 14, backgroundColor: '#fff', borderRadius: 16, padding: 14, marginBottom: 8, borderWidth: 2, borderColor: 'transparent' },
  vehRowOn: { backgroundColor: C.black, borderColor: C.pink },
  seg: { flexDirection: 'row', backgroundColor: C.bg, borderRadius: 12, padding: 4, marginBottom: 10 },
  segItem: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 9 },
  age: { paddingHorizontal: 12, paddingVertical: 9, borderRadius: 18, backgroundColor: C.bg },
  ageOn: { backgroundColor: C.blue },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fff', borderRadius: 22, paddingHorizontal: 14, paddingVertical: 10, borderWidth: 1.5, borderColor: C.line },
  chipOn: { backgroundColor: C.blue, borderColor: C.blue },
  pay: { flex: 1, alignItems: 'center', gap: 6, paddingVertical: 14, borderRadius: 14, borderWidth: 2, borderColor: C.line, backgroundColor: C.bg },
  bottom: { flexDirection: 'row', alignItems: 'center', gap: 16, backgroundColor: '#fff', paddingHorizontal: 16, paddingTop: 12, borderTopWidth: 1, borderColor: C.line },
});
