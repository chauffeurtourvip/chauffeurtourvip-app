import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, ScrollView, Linking, ActivityIndicator } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { doc, getDoc, onSnapshot, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { decodePolyline } from '../google';
import { sendPush } from '../push';
import { COMPANY } from '../config';
import { C, s, STATUS, fmtDate, MAP_STYLE } from '../theme';
import { Pin, MapPin, CarMarker, Ionicons, Btn } from '../ui';

const STEPS = ['pending', 'accepted', 'enroute', 'arrived', 'onboard', 'done'];
const STEP_TXT = { pending: 'Demande envoyée', accepted: 'Confirmée', enroute: 'Chauffeur en route', arrived: 'Chauffeur arrivé', onboard: 'En course', done: 'Arrivé à destination' };

export default function RideScreen({ route, navigation }) {
  const { id, justBooked } = route.params;
  const ins = useSafeAreaInsets();
  const map = useRef(null);
  const [r, setR] = useState(null);
  const [driver, setDriver] = useState(null);
  const [sure, setSure] = useState(false);

  useEffect(() => onSnapshot(doc(db, 'rides', id), (d) => setR(d.exists() ? { id: d.id, ...d.data() } : false)), [id]);
  useEffect(() => { getDoc(doc(db, 'settings', 'driver')).then((d) => setDriver(d.data() || {})).catch(() => setDriver({})); }, []);

  const coords = useMemo(() => (r?.polyline ? decodePolyline(r.polyline) : []), [r?.polyline]);
  const dl = r?.driverLocation;
  useEffect(() => {
    if (!map.current || !coords.length) return;
    const pts = dl && ['enroute', 'arrived'].includes(r.status) ? [{ latitude: dl.lat, longitude: dl.lng }, coords[0]] : coords;
    map.current.fitToCoordinates(pts, { edgePadding: { top: 50, bottom: 50, left: 50, right: 50 }, animated: true });
  }, [coords.length, r?.status, dl?.lat]);

  if (r === null) return <ActivityIndicator style={{ flex: 1 }} color={C.ink} />;
  if (r === false) return <Text style={{ padding: 20 }}>Course introuvable.</Text>;

  const idx = STEPS.indexOf(r.status);
  const closed = ['done', 'cancelled', 'refused'].includes(r.status);
  const phone = driver?.phone || COMPANY.phone;

  async function cancel() {
    if (!sure) { setSure(true); return; }
    await updateDoc(doc(db, 'rides', id), { status: 'cancelled' });
    sendPush(driver?.pushToken, 'Course annulée par le client', `${fmtDate(r.date)} — ${r.clientName}`, { rideId: id, driver: true });
  }

  return (
    <View style={s.screen}>
      <MapView ref={map} provider={PROVIDER_GOOGLE} customMapStyle={MAP_STYLE} style={{ height: '42%' }}
        initialRegion={{ latitude: r.pickup.lat, longitude: r.pickup.lng, latitudeDelta: 0.1, longitudeDelta: 0.1 }}>
        <Marker coordinate={{ latitude: r.pickup.lat, longitude: r.pickup.lng }} anchor={{ x: 0.5, y: 0.5 }}><MapPin kind="from" /></Marker>
        <Marker coordinate={{ latitude: r.dropoff.lat, longitude: r.dropoff.lng }} anchor={{ x: 0.5, y: 0.5 }}><MapPin kind="to" /></Marker>
        {coords.length > 0 && <Polyline coordinates={coords} strokeColor={C.black} strokeWidth={5} />}
        {dl && !closed && r.status !== 'pending' && (
          <Marker coordinate={{ latitude: dl.lat, longitude: dl.lng }} title="Votre chauffeur" anchor={{ x: 0.5, y: 0.5 }}>
            <CarMarker />
          </Marker>
        )}
      </MapView>

      <ScrollView style={{ marginTop: -20, borderTopLeftRadius: 24, borderTopRightRadius: 24, backgroundColor: C.bg }} contentContainerStyle={{ padding: 18, paddingBottom: ins.bottom + 20 }}>
        {justBooked && r.status === 'pending' && (
          <View style={[s.card, { backgroundColor: C.blueSoft }]}>
            <Text style={{ fontWeight: '700', fontSize: 16 }}>Demande envoyée ✓</Text>
            <Text style={s.mut}>Votre chauffeur va confirmer la course. Vous recevrez une notification.</Text>
          </View>
        )}
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Ionicons name={STATUS[r.status]?.icon} size={28} color={STATUS[r.status]?.color} />
          <Text style={[s.h1, { color: STATUS[r.status]?.color, flex: 1 }]}>{STATUS[r.status]?.label}</Text>
        </View>
        <Text style={[s.mut, { marginBottom: 12 }]}>{fmtDate(r.date)} · {r.vehicle} · {r.pax} pass.{r.roundTrip && r.returnDate ? `\nRetour : ${fmtDate(r.returnDate)}` : ''}{r.childSeats?.length ? `\nSièges enfant : ${r.childSeats.join(', ')}` : ''}</Text>

        {!closed && (
          <View style={{ flexDirection: 'row', marginBottom: 14 }}>
            {STEPS.slice(0, 5).map((st, i) => (
              <View key={st} style={{ flex: 1, alignItems: 'center' }}>
                <View style={{ height: 5, borderRadius: 3, marginHorizontal: 2, alignSelf: 'stretch', backgroundColor: i <= idx ? C.pink : C.line, marginBottom: 6 }} />
                <Text style={{ fontSize: 10, textAlign: 'center', color: i <= idx ? C.ink : C.mut }}>{STEP_TXT[st]}</Text>
              </View>
            ))}
          </View>
        )}

        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', marginBottom: 6 }}><Pin kind="from" /><Text style={{ flex: 1 }}>{r.pickup.address}</Text></View>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', marginBottom: 12 }}><Pin kind="to" /><Text style={{ flex: 1 }}>{r.dropoff.address}</Text></View>

        <View style={[s.card, { flexDirection: 'row', justifyContent: 'space-between' }]}>
          <View><Text style={s.label}>Tarif garanti</Text><Text style={{ fontSize: 22, fontWeight: '700' }}>{r.price} €</Text></View>
          <View style={{ alignItems: 'flex-end' }}><Text style={s.label}>Trajet</Text><Text>{r.distanceKm} km · {r.durationMin} min</Text><Text style={s.mut}>{r.payment}</Text></View>
        </View>

        {!closed && r.status !== 'pending' && (
          <View style={s.card}>
            <Text style={s.label}>Votre chauffeur</Text>
            <Text style={{ fontSize: 17, fontWeight: '700' }}>{driver?.name || COMPANY.name}</Text>
            {!!driver?.car && <Text style={s.mut}>{driver.car}</Text>}
          </View>
        )}

        {!closed && (
          <View style={{ flexDirection: 'row', gap: 10, marginBottom: 10 }}>
            <Btn icon="call" title="Appeler" style={{ flex: 1 }} onPress={() => Linking.openURL('tel:' + phone)} />
            <Btn icon="logo-whatsapp" title="WhatsApp" variant="ghost" style={{ flex: 1 }} onPress={() => Linking.openURL('https://wa.me/' + phone.replace(/\D/g, ''))} />
          </View>
        )}
        {['pending', 'accepted'].includes(r.status) && (
          <Pressable style={s.ghostBtn} onPress={cancel}>
            <Text style={[s.ghostTxt, sure && { color: C.pink }]}>{sure ? 'Confirmer l\'annulation' : 'Annuler la course'}</Text>
          </Pressable>
        )}
        {r.status === 'done' && <Text style={{ fontSize: 16, marginTop: 6 }}>Merci d'avoir voyagé avec {COMPANY.name} !</Text>}
        {closed && (
          <Pressable style={[s.ghostBtn, { marginTop: 12 }]} onPress={() => navigation.popToTop()}><Text style={s.ghostTxt}>Nouvelle réservation</Text></Pressable>
        )}
      </ScrollView>
    </View>
  );
}
