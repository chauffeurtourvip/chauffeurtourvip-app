import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, ScrollView, Linking, ActivityIndicator } from 'react-native';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { doc, onSnapshot, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { sendPush } from '../push';
import { C, s, STATUS, fmtDate } from '../theme';
import { Pin, Btn, Ionicons } from '../ui';

// Étape suivante pour chaque statut : [nouveau statut, texte du bouton, notification au client]
const NEXT = {
  pending: ['accepted', 'Accepter la course', 'Votre course est confirmée ✓'],
  accepted: ['enroute', 'Je pars chercher le client', 'Votre chauffeur est en route'],
  enroute: ['arrived', 'Je suis arrivé', 'Votre chauffeur est arrivé au point de rendez-vous'],
  arrived: ['onboard', 'Client à bord', null],
  onboard: ['done', 'Course terminée', 'Merci et à bientôt !'],
};
const SHARE = ['enroute', 'arrived', 'onboard'];

export default function DriverRideScreen({ route }) {
  const { id } = route.params;
  const ins = useSafeAreaInsets();
  const [r, setR] = useState(null);
  const [busy, setBusy] = useState(false);
  const [sure, setSure] = useState('');
  const [gps, setGps] = useState('');
  const watch = useRef(null);

  useEffect(() => onSnapshot(doc(db, 'rides', id), (d) => setR(d.exists() ? { id: d.id, ...d.data() } : false)), [id]);

  // Partage de la position en direct au client pendant la course (écran ouvert)
  const sharing = r && SHARE.includes(r.status);
  useEffect(() => {
    if (!sharing) return;
    let cancelled = false;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') { setGps('Position refusée : le client ne voit pas la voiture.'); return; }
      const sub = await Location.watchPositionAsync(
        { accuracy: Location.Accuracy.High, timeInterval: 10000, distanceInterval: 40 },
        (p) => {
          updateDoc(doc(db, 'rides', id), { driverLocation: { lat: p.coords.latitude, lng: p.coords.longitude, at: Date.now() } }).catch(() => {});
          setGps('Position partagée avec le client ●');
        }
      );
      if (cancelled) sub.remove(); else watch.current = sub;
    })();
    return () => { cancelled = true; watch.current?.remove(); watch.current = null; };
  }, [sharing, id]);

  if (r === null) return <ActivityIndicator style={{ flex: 1 }} color={C.ink} />;
  if (r === false) return <Text style={{ padding: 20 }}>Course introuvable.</Text>;

  async function setStatus(st, msg) {
    setBusy(true);
    try {
      await updateDoc(doc(db, 'rides', id), { status: st, [`${st}At`]: serverTimestamp() });
      if (msg) sendPush(r.clientPushToken, msg, `${fmtDate(r.date)} — ${r.pickup.address}`, { rideId: id });
    } catch (e) { setGps(e.message); }
    setBusy(false); setSure('');
  }

  const next = NEXT[r.status];
  const target = r.status === 'onboard' ? r.dropoff : r.pickup;
  const nav = () => Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${target.lat},${target.lng}&travelmode=driving`);
  const waze = () => Linking.openURL(`https://waze.com/ul?ll=${target.lat},${target.lng}&navigate=yes`);
  const tel = (r.clientPhone || '').replace(/\s/g, '');
  const wa = tel.replace(/^0/, '33').replace(/\D/g, '');

  return (
    <View style={s.screen}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={[s.h1, { color: STATUS[r.status]?.color }]}>{STATUS[r.status]?.label}</Text>
        <Text style={{ fontSize: 18, fontWeight: '700', marginVertical: 6 }}>{fmtDate(r.date)} · {r.price} €</Text>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', marginBottom: 6 }}><Pin kind="from" /><Text style={{ flex: 1, fontSize: 15 }}>{r.pickup.address}</Text></View>
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'center', marginBottom: 10 }}><Pin kind="to" /><Text style={{ flex: 1, fontSize: 15 }}>{r.dropoff.address}</Text></View>
        <Text style={s.mut}>{r.distanceKm} km · {r.durationMin} min · {r.vehicle} · {r.pax} passager(s){r.bags ? ` · ${r.bags} bagage(s)` : ''}</Text>
        <Text style={s.mut}>Paiement : {r.payment}</Text>
        {!!r.flight && <Text style={{ marginTop: 4 }}>Vol / train : <Text style={{ fontWeight: '700' }}>{r.flight}</Text></Text>}
        {r.roundTrip && r.returnDate && <Text style={{ marginTop: 4, fontWeight: '700', color: C.pink }}>Aller-retour · retour le {fmtDate(r.returnDate)}</Text>}
        {r.childSeats?.length > 0 && <Text style={{ marginTop: 4, fontWeight: '700' }}>Sièges enfant : {r.childSeats.join(', ')}</Text>}
        {!!r.passenger && <Text style={{ marginTop: 4, color: C.blue }}>Passager : {r.passenger.name} · {r.passenger.phone}</Text>}
        {r.options?.length > 0 && <Text style={{ marginTop: 4 }}>Options : {r.options.join(', ')}</Text>}
        {!!r.comment && <Text style={{ marginTop: 4, fontStyle: 'italic' }}>« {r.comment} »</Text>}

        <View style={[s.card, { marginTop: 14 }]}>
          <Text style={s.label}>Client</Text>
          <Text style={{ fontSize: 17, fontWeight: '700' }}>{r.clientName}</Text>
          <Text style={s.mut}>{r.clientPhone} · {r.clientEmail}</Text>
          <View style={{ flexDirection: 'row', gap: 10, marginTop: 10 }}>
            <Btn icon="call" title="Appeler" style={{ flex: 1 }} onPress={() => Linking.openURL('tel:' + tel)} />
            <Btn icon="logo-whatsapp" title="WhatsApp" variant="ghost" style={{ flex: 1 }} onPress={() => Linking.openURL('https://wa.me/' + wa)} />
          </View>
        </View>

        {!['done', 'cancelled', 'refused'].includes(r.status) && (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Btn icon="navigate" title="Google Maps" variant="ghost" style={{ flex: 1 }} onPress={nav} />
            <Btn icon="map" title="Waze" variant="ghost" style={{ flex: 1 }} onPress={waze} />
          </View>
        )}
        {!!gps && <Text style={[s.mut, { marginTop: 10, color: C.blue }]}>{gps}</Text>}
        {sharing && <Text style={[s.mut, { marginTop: 4 }]}>Gardez cet écran ouvert pour que le client voie la voiture.</Text>}

        {['pending', 'accepted'].includes(r.status) && (
          <Pressable style={{ padding: 16, alignItems: 'center' }} onPress={() => sure === 'refuse' ? setStatus(r.status === 'pending' ? 'refused' : 'cancelled', 'Désolé, votre chauffeur n\'est pas disponible pour cette course.') : setSure('refuse')}>
            <Text style={{ color: C.pink }}>{sure === 'refuse' ? 'Confirmer : refuser / annuler la course' : r.status === 'pending' ? 'Refuser (indisponible)' : 'Annuler la course'}</Text>
          </Pressable>
        )}
      </ScrollView>

      {next && (
        <Pressable style={[s.accentBtn, { borderRadius: 0, paddingBottom: ins.bottom, minHeight: 64 + ins.bottom }]} disabled={busy} onPress={() => setStatus(next[0], next[2])}>
          {busy ? <ActivityIndicator color="#fff" /> : <Text style={s.accentTxt}>{next[1]}</Text>}
        </Pressable>
      )}
    </View>
  );
}
