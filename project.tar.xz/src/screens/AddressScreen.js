import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, TextInput, Pressable, FlatList, ActivityIndicator } from 'react-native';
import { useApp } from '../store';
import { autocomplete, placeDetails, newSessionToken } from '../google';
import { FAVORITES } from '../config';
import { C, s } from '../theme';
import { Pin } from '../ui';

export default function AddressScreen({ route, navigation }) {
  const field = route.params?.field || 'dropoff';
  const { pickup, setPickup, setDropoff } = useApp();
  const [q, setQ] = useState('');
  const [res, setRes] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const token = useMemo(newSessionToken, []);
  const timer = useRef(null);

  useEffect(() => {
    navigation.setOptions({ title: field === 'pickup' ? 'Point de départ' : 'Destination' });
  }, [field]);

  useEffect(() => {
    clearTimeout(timer.current);
    if (q.trim().length < 3) { setRes([]); return; }
    timer.current = setTimeout(async () => {
      setBusy(true); setErr('');
      try { setRes(await autocomplete(q.trim(), pickup, token)); }
      catch (e) { setErr('Recherche impossible : ' + e.message); }
      setBusy(false);
    }, 350);
    return () => clearTimeout(timer.current);
  }, [q]);

  function choose(place) {
    (field === 'pickup' ? setPickup : setDropoff)(place);
    navigation.goBack();
  }

  async function pick(item) {
    setBusy(true);
    try { choose(await placeDetails(item.id, token)); }
    catch (e) { setErr(e.message); setBusy(false); }
  }

  const color = field === 'pickup' ? C.blue : C.pink;
  return (
    <View style={s.screen}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderBottomWidth: 1, borderColor: C.line }}>
        <Pin kind={field === 'pickup' ? 'from' : 'to'} />
        <TextInput
          autoFocus
          style={[s.input, { flex: 1 }]}
          placeholder={field === 'pickup' ? 'Adresse de prise en charge' : 'Adresse de destination'}
          value={q}
          onChangeText={setQ}
          returnKeyType="search"
        />
        {busy && <ActivityIndicator color={C.ink} />}
      </View>
      {!!err && <Text style={[s.err, { paddingHorizontal: 14 }]}>{err}</Text>}
      <FlatList
        keyboardShouldPersistTaps="handled"
        data={q.trim().length >= 3 ? res : FAVORITES.map((f) => ({ fav: f, id: f.address }))}
        keyExtractor={(i) => i.id}
        ListHeaderComponent={q.trim().length < 3 ? <Text style={[s.label, { padding: 14, paddingBottom: 4 }]}>Lieux fréquents</Text> : null}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => (item.fav ? choose(item.fav) : pick(item))}
            style={({ pressed }) => [{ paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: 1, borderColor: C.line }, pressed && { backgroundColor: C.bg }]}>
            <Text style={{ fontSize: 16 }}>{item.fav ? item.fav.address : item.main}</Text>
            {!item.fav && !!item.sub && <Text style={s.mut}>{item.sub}</Text>}
          </Pressable>
        )}
        ListEmptyComponent={q.trim().length >= 3 && !busy ? <Text style={[s.mut, { padding: 14 }]}>Aucun résultat.</Text> : null}
      />
    </View>
  );
}
