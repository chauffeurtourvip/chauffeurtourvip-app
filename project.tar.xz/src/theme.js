import { StyleSheet, Platform } from 'react-native';

// Identité premium : noir, blanc, doré
export const C = {
  ink: '#111113',
  ink2: '#2a2a2e',
  mut: '#7a7a82',
  line: '#ececef',
  bg: '#f5f5f7',
  card: '#ffffff',
  black: '#0b0b0d',
  white: '#ffffff',
  // accents
  pink: '#ec3a77',      // rose : action principale
  pinkDark: '#c81f5a',
  pinkSoft: '#fde8ef',
  red: '#e0263f',       // rouge : arrivée, alertes
  blue: '#2563eb',      // bleu : départ, infos, chauffeur
  blueSoft: '#e6eeff',
  green: '#1f9d6b',
};

export const STATUS = {
  pending: { label: 'En attente de confirmation', color: C.blue, icon: 'time-outline' },
  accepted: { label: 'Course confirmée', color: C.green, icon: 'checkmark-circle-outline' },
  enroute: { label: 'Chauffeur en route', color: C.green, icon: 'car-sport-outline' },
  arrived: { label: 'Votre chauffeur est arrivé', color: C.pink, icon: 'location-outline' },
  onboard: { label: 'En course', color: C.ink, icon: 'navigate-outline' },
  done: { label: 'Terminée', color: C.mut, icon: 'flag-outline' },
  cancelled: { label: 'Annulée', color: C.mut, icon: 'close-circle-outline' },
  refused: { label: 'Chauffeur indisponible', color: C.red, icon: 'alert-circle-outline' },
};
export const ACTIVE = ['pending', 'accepted', 'enroute', 'arrived', 'onboard'];

const shadow = Platform.select({
  android: { elevation: 3 },
  default: { shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 10, shadowOffset: { width: 0, height: 3 } },
});

export const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  // Bouton principal noir et or
  blackBtn: { backgroundColor: C.black, minHeight: 56, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', paddingHorizontal: 18, gap: 8 },
  blackTxt: { color: C.white, fontSize: 16, fontWeight: '700', letterSpacing: 0.3 },
  accentBtn: { backgroundColor: C.pink, minHeight: 56, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', paddingHorizontal: 18, gap: 8 },
  accentTxt: { color: C.white, fontSize: 16, fontWeight: '800', letterSpacing: 0.3 },
  ghostBtn: { borderWidth: 1.5, borderColor: C.line, backgroundColor: C.card, minHeight: 50, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', paddingHorizontal: 16, gap: 8 },
  ghostTxt: { color: C.ink, fontSize: 15, fontWeight: '600' },
  label: { fontSize: 12, color: C.mut, fontWeight: '600', letterSpacing: 0.2, marginBottom: 6 },
  field: { backgroundColor: C.card, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, marginBottom: 10, borderWidth: 1, borderColor: C.line },
  input: { fontSize: 16, color: C.ink, paddingVertical: 4, minHeight: 36 },
  card: { backgroundColor: C.card, borderRadius: 18, padding: 16, marginBottom: 12, ...shadow },
  h1: { fontSize: 26, fontWeight: '800', color: C.ink, letterSpacing: -0.3 },
  h2: { fontSize: 18, fontWeight: '700', color: C.ink },
  mut: { color: C.mut, fontSize: 14 },
  err: { color: C.red, fontSize: 14, marginVertical: 6 },
  shadow,
});

export function fmtDate(d) {
  const x = d?.toDate ? d.toDate() : new Date(d);
  const day = x.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
  const h = x.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  return `${day} · ${h}`;
}

// Style de carte sobre (gris clair, routes blanches) pour faire ressortir le noir et l'or
export const MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#f2f0eb' }] },
  { elementType: 'labels.icon', stylers: [{ visibility: 'off' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6b6b70' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#f7f5f0' }] },
  { featureType: 'poi', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit.station.airport', stylers: [{ visibility: 'on' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#ffffff' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#dfe3ec' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#cfdde3' }] },
  { featureType: 'landscape.natural', elementType: 'geometry', stylers: [{ color: '#ebe8df' }] },
];
