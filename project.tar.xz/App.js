import React, { useEffect } from 'react';
import * as Notifications from 'expo-notifications';
import { ActivityIndicator, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, createNavigationContainerRef } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppProvider, useApp } from './src/store';
import AuthScreen from './src/screens/AuthScreen';
import HomeScreen from './src/screens/HomeScreen';
import AddressScreen from './src/screens/AddressScreen';
import BookScreen from './src/screens/BookScreen';
import RideScreen from './src/screens/RideScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import DriverScreen from './src/screens/DriverScreen';
import DriverRideScreen from './src/screens/DriverRideScreen';

const Stack = createNativeStackNavigator();
const navRef = createNavigationContainerRef();
const head = (title) => ({
  title,
  headerStyle: { backgroundColor: '#ffffff' },
  headerTintColor: '#111113',
  headerTitleStyle: { fontWeight: '700', fontSize: 17 },
  headerShadowVisible: false,
});

function Root() {
  const { user } = useApp();
  if (user === undefined) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" color="#111" />
      </View>
    );
  }
  return (
    <Stack.Navigator>
      {!user ? (
        <Stack.Screen name="Auth" component={AuthScreen} options={{ headerShown: false }} />
      ) : (
        <>
          <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Address" component={AddressScreen} options={head('Adresse')} />
          <Stack.Screen name="Book" component={BookScreen} options={head('Finaliser la réservation')} />
          <Stack.Screen name="Ride" component={RideScreen} options={head('Ma course')} />
          <Stack.Screen name="History" component={HistoryScreen} options={head('Mes réservations')} />
          <Stack.Screen name="Profile" component={ProfileScreen} options={head('Mon profil')} />
          <Stack.Screen name="Driver" component={DriverScreen} options={head('Espace chauffeur')} />
          <Stack.Screen name="DriverRide" component={DriverRideScreen} options={head('Course')} />
        </>
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  // Toucher une notification ouvre directement la course
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((resp) => {
      const d = resp.notification.request.content.data || {};
      if (d.rideId && navRef.isReady()) navRef.navigate(d.driver ? 'DriverRide' : 'Ride', { id: d.rideId });
    });
    return () => sub.remove();
  }, []);
  return (
    <SafeAreaProvider>
      <AppProvider>
        <NavigationContainer ref={navRef}>
          <StatusBar style="dark" />
          <Root />
        </NavigationContainer>
      </AppProvider>
    </SafeAreaProvider>
  );
}
