import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, Modal, StyleSheet, Linking, ActivityIndicator, ScrollView, Platform } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_GOOGLE } from 'react-native-maps';
import * as Location from 'expo-location';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { auth, db } from '../firebase';
import { useApp } from '../store';
import { C, s, STATUS, ACTIVE, MAP_STYLE, fmtDate } from '../theme';
import { MAP_CENTER, VEHICLES, COMPANY, FAVORITES, priceFor, totalPrice } from '../config';
import { decodePolyline } from '../google';
import { Pin, MapPin, Ionicons, VehicleIcon, Btn, Logo, pickDateTime } from '../ui';

const FAV_ICON = (a) => (/aéroport/i.test(a) ? 'airplane' : /gare/i.test(a) ? 'train' : /plage/i.test(a) ? 'sunny' : 'location');


export default function HomeScreen({ navigation }) {
  const ins = useSafeAreaInsets();
  const map = useRef(null);
  const { user, profile, isDriver, pickup, setPickup, dropoff, setDropoff, trip, veh, setVeh, when, setWhen, roundTrip, setRoundTrip, returnAt, setReturnAt } = useApp();
  const [iosTarget, setIosTarget] = useState('when');
  const [menu, setMenu] = useState(false);
  const [tarifs, setTarifs] = useState(false);
  const [active, setActive] = useState(null);
  const [locMsg, setLocMsg] = useState('');
  const [iosPicker, setIosPicker] = useState(false);

  async function locate(force) {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') { setLocMsg('Saisissez votre adresse de départ'); return; }
      const p = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const { latitude, longitude } = p.coords;
      map.current?.animateToRegion({ latitude, longitude, latitudeDelta: 0.025, longitudeDelta: 0.025 }, 600);
      if (!pickup || force) {
        let address = 'Ma position';
        try {
          const [g] = await Location.reverseGeocodeAsync({ latitude, longitude });
          if (g) address = [g.streetNumber, g.street, g.city].filter(Boolean).join(' ') || address;
        } catch {}
        setPickup({ address, lat: latitude, lng: longitude });
      }
    } catch (e) { setLocMsg('Position introuvable'); }
  }
  useEffect(() => { locate(false); }, []);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'rides'), where('clientId', '==', user.uid), where('status', 'in', ACTIVE));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
      list.sort((a, b) => (a.date?.seconds || 0) - (b.date?.seconds || 0));
      setActive(list[0] || null);
    }, () => {});
  }, [user?.uid]);

  const coords = useMemo(() => (trip && trip.polyline ? decodePolyline(trip.polyline) : null), [trip]);
  useEffect(() => {
    if (coords && map.current) map.current.fitToCoordinates(coords, { edgePadding: { top: ins.top + 90, bottom: 40, left: 50, right: 50 }, animated: true });
  }, [coords]);

  const km = trip && trip.km != null ? trip.km : null;
  const selected = VEHICLES.find((v) => v.id === veh) || VEHICLES[0];
  const price = totalPrice(selected, km, when, roundTrip, returnAt, pickup, dropoff);
  const firstName = (profile?.name || user?.displayName || '').split(' ')[0];
  const go = (screen, params) => { setMenu(false); navigation.navigate(screen, params); };

  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <MapView ref={map} provider={PROVIDER_GOOGLE} style={{ flex: 1 }} customMapStyle={MAP_STYLE} initialRegion={MAP_CENTER}
        showsUserLocation showsMyLocationButton={false} toolbarEnabled={false} showsCompass={false}>
        {pickup && <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }} anchor={{ x: 0.5, y: 0.5 }}><MapPin kind="from" /></Marker>}
        {dropoff && <Marker coordinate={{ latitude: dropoff.lat, longitude: dropoff.lng }} anchor={{ x: 0.5, y: 0.5 }}><MapPin kind="to" /></Marker>}
        {coords && <Polyline coordinates={coords} strokeColor={C.black} strokeWidth={5} />}
      </MapView>

      {/* Boutons flottants */}
      <Pressable style={[st.fab, { top: ins.top + 12, left: 16 }]} onPress={() => setMenu(true)} accessibilityLabel="Menu">
        <Ionicons name="menu" size={24} color={C.ink} />
      </Pressable>
      <Pressable style={[st.fab, { top: ins.top + 12, right: 16 }]} onPress={() => locate(true)} accessibilityLabel="Me localiser">
        <Ionicons name="locate" size={22} color={C.ink} />
      </Pressable>

      {active && (
        <Pressable style={[st.banner, { top: ins.top + 72 }]} onPress={() => navigation.navigate('Ride', { id: active.id })}>
          <View style={st.bannerIcon}><Ionicons name={STATUS[active.status]?.icon} size={20} color="#fff" /></View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#fff', fontWeight: '700' }}>{STATUS[active.status]?.label}</Text>
            <Text style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13 }}>{fmtDate(active.date)}</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#fff" />
        </Pressable>
      )}

      {/* Panneau du bas */}
      <View style={[st.sheet, { paddingBottom: ins.bottom + 16 }]}>
        <View style={st.grab} />
        {!dropoff ? (
          <>
            <Text style={{ color: C.mut, fontSize: 15 }}>{firstName ? `Bonjour ${firstName}` : 'Bonjour'} 👋</Text>
            <Text style={[s.h1, { marginBottom: 14 }]}>Où allez-vous ?</Text>
            <Pressable style={st.search} onPress={() => navigation.navigate('Address', { field: 'dropoff' })}>
              <Ionicons name="search" size={22} color={C.ink} />
              <Text style={{ flex: 1, fontSize: 17, color: C.mut }}>Rechercher une destination</Text>
              <Pressable style={st.nowChip} onPress={() => pickDateTime(when, setWhen, setIosPicker)}>
                <Ionicons name="time-outline" size={16} color={C.ink} />
                <Text style={{ fontWeight: '600', fontSize: 13 }}>{when ? 'Programmé' : 'Maintenant'}</Text>
              </Pressable>
            </Pressable>
            <Pressable style={st.fromRow} onPress={() => navigation.navigate('Address', { field: 'pickup' })}>
              <Pin kind="from" />
              <Text numberOfLines={1} style={{ flex: 1, color: pickup ? C.ink : C.mut }}>{pickup?.address || locMsg || 'Recherche de votre position…'}</Text>
              <Text style={{ color: C.pinkDark, fontWeight: '600' }}>Modifier</Text>
            </Pressable>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingTop: 6 }}>
              {FAVORITES.map((f) => (
                <Pressable key={f.address} style={st.fav} onPress={() => setDropoff(f)}>
                  <View style={st.favIcon}><Ionicons name={FAV_ICON(f.address)} size={16} color="#fff" /></View>
                  <Text style={{ fontWeight: '600', fontSize: 14 }} numberOfLines={1}>{f.address.replace('Méditerranée', '').trim()}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </>
        ) : (
          <>
            {/* Trajet */}
            <View style={st.routeCard}>
              <View style={{ alignItems: 'center', paddingTop: 6 }}>
                <Pin kind="from" />
                <View style={{ width: 2, flex: 1, backgroundColor: C.line, marginVertical: 3 }} />
                <Pin kind="to" />
              </View>
              <View style={{ flex: 1 }}>
                <Pressable onPress={() => navigation.navigate('Address', { field: 'pickup' })} style={{ paddingVertical: 6 }}>
                  <Text numberOfLines={1} style={{ fontSize: 15 }}>{pickup?.address || 'Adresse de départ'}</Text>
                </Pressable>
                <View style={{ height: 1, backgroundColor: C.line }} />
                <Pressable onPress={() => navigation.navigate('Address', { field: 'dropoff' })} style={{ paddingVertical: 6 }}>
                  <Text numberOfLines={1} style={{ fontSize: 15, fontWeight: '600' }}>{dropoff.address}</Text>
                </Pressable>
              </View>
              <Pressable hitSlop={10} onPress={() => setDropoff(null)} style={{ padding: 4 }}><Ionicons name="close" size={22} color={C.mut} /></Pressable>
            </View>

            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: 10 }}>
              <Text style={s.h2}>Choisissez votre véhicule</Text>
              {trip === 'loading' ? <ActivityIndicator color={C.pink} /> : km != null ? <Text style={s.mut}>{Math.round(km)} km · {trip.min} min</Text> : null}
            </View>
            {trip?.error && <Text style={s.err}>Itinéraire introuvable. Vérifiez les adresses.</Text>}

            <View style={st.seg}>
              {[[false, 'Aller simple'], [true, 'Aller-retour']].map(([val, t]) => (
                <Pressable key={t} onPress={() => setRoundTrip(val)} style={[st.segItem, roundTrip === val && st.segOn]}>
                  <Ionicons name={val ? 'repeat' : 'arrow-forward'} size={16} color={roundTrip === val ? '#fff' : C.ink} />
                  <Text style={{ fontWeight: '700', color: roundTrip === val ? '#fff' : C.ink }}>{t}</Text>
                </Pressable>
              ))}
            </View>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              {VEHICLES.map((v) => {
                const on = v.id === veh;
                const p = totalPrice(v, km, when, roundTrip, returnAt, pickup, dropoff);
                return (
                  <Pressable key={v.id} onPress={() => setVeh(v.id)} style={[st.veh, on && st.vehOn]}>
                    <VehicleIcon id={v.id} size={40} color={on ? '#fff' : C.ink} />
                    <Text style={{ fontWeight: '700', fontSize: 16, color: on ? '#fff' : C.ink }}>{v.name}</Text>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <Ionicons name="person" size={12} color={on ? '#ccc' : C.mut} /><Text style={{ fontSize: 12, color: on ? '#ccc' : C.mut }}>{v.seats}</Text>
                      <Ionicons name="briefcase" size={12} color={on ? '#ccc' : C.mut} /><Text style={{ fontSize: 12, color: on ? '#ccc' : C.mut }}>{v.bags}</Text>
                    </View>
                    <Text style={{ fontSize: 22, fontWeight: '800', color: on ? C.pink : C.ink, marginTop: 4 }}>{p != null ? p + ' €' : '—'}</Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={[s.mut, { marginTop: 6 }]} numberOfLines={1}>{selected.model} · {selected.equip.join(' · ')}</Text>

            <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
              <Pressable style={st.whenBtn} onPress={() => { setIosTarget('when'); pickDateTime(when, setWhen, setIosPicker); }}>
                <Text style={{ fontSize: 11, color: C.mut }}>Aller</Text>
                <Text style={{ fontWeight: '600', fontSize: 13, textAlign: 'center' }} numberOfLines={2}>{when ? fmtDate(when) : 'Maintenant'}</Text>
              </Pressable>
              {roundTrip && (
                <Pressable style={[st.whenBtn, !returnAt && { borderColor: C.red }]} onPress={() => { setIosTarget('ret'); pickDateTime(returnAt || when, setReturnAt, setIosPicker); }}>
                  <Text style={{ fontSize: 11, color: C.mut }}>Retour</Text>
                  <Text style={{ fontWeight: '600', fontSize: 13, textAlign: 'center', color: returnAt ? C.ink : C.red }} numberOfLines={2}>{returnAt ? fmtDate(returnAt) : 'Choisir'}</Text>
                </Pressable>
              )}
              <Btn variant="accent" style={{ flex: 1 }} title={price != null ? `Réserver · ${price} €` : 'Réserver'} disabled={km == null || (roundTrip && !returnAt)} onPress={() => navigation.navigate('Book')} />
            </View>
          </>
        )}
      </View>

      {iosPicker && <DateTimePicker value={(iosTarget === 'ret' ? returnAt : when) || new Date()} mode="datetime" minimumDate={new Date()} onChange={(e, d) => { setIosPicker(false); if (d) (iosTarget === 'ret' ? setReturnAt : setWhen)(d); }} />}

      {/* Menu latéral */}
      <Modal visible={menu} transparent animationType="fade" onRequestClose={() => setMenu(false)}>
        <Pressable style={st.veil} onPress={() => setMenu(false)}>
          <Pressable style={[st.drawer, { paddingTop: ins.top + 24 }]}>
            <View style={{ paddingHorizontal: 22, paddingBottom: 22 }}>
              <Logo dark />
              <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', marginTop: 18 }}>{profile?.name || user?.displayName || 'Bienvenue'}</Text>
              <Text style={{ color: 'rgba(255,255,255,0.6)' }}>{user?.email}</Text>
            </View>
            <View style={{ flex: 1, backgroundColor: '#fff', borderTopRightRadius: 24, paddingTop: 10 }}>
              <Item icon="car-sport-outline" t="Réserver une course" onPress={() => setMenu(false)} />
              <Item icon="receipt-outline" t="Mes réservations" onPress={() => go('History')} />
              <Item icon="person-circle-outline" t="Mon profil" onPress={() => go('Profile')} />
              <Item icon="pricetags-outline" t="Nos tarifs" onPress={() => { setMenu(false); setTarifs(true); }} />
              <Item icon="call-outline" t="Appeler le chauffeur" onPress={() => Linking.openURL('tel:' + COMPANY.phone)} />
              <Item icon="logo-whatsapp" t="WhatsApp" onPress={() => Linking.openURL('https://wa.me/' + COMPANY.phone.replace(/\D/g, ''))} />
              {isDriver && <Item icon="speedometer-outline" t="Mode chauffeur" accent onPress={() => go('Driver')} />}
              <View style={{ flex: 1 }} />
              <Item icon="log-out-outline" t="Déconnexion" onPress={() => { setMenu(false); signOut(auth); }} />
              <View style={{ height: ins.bottom + 10 }} />
            </View>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Tarifs */}
      <Modal visible={tarifs} transparent animationType="slide" onRequestClose={() => setTarifs(false)}>
        <Pressable style={[st.veil, { justifyContent: 'flex-end' }]} onPress={() => setTarifs(false)}>
          <Pressable style={[st.tarifSheet, { paddingBottom: ins.bottom + 16 }]}>
            <View style={st.grab} />
            <Text style={s.h1}>Nos tarifs</Text>
            <Text style={[s.mut, { marginVertical: 8 }]}>Prix fixe calculé sur l'itinéraire Google : 5 € de prise en charge + le prix au km, avec un minimum par course. Le prix affiché est garanti, même dans les bouchons.</Text>
            {VEHICLES.map((v) => (
              <View key={v.id} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderColor: C.line }}>
                <VehicleIcon id={v.id} size={30} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700' }}>{v.name}</Text>
                  <Text style={s.mut}>{v.seats} places · {v.bags} bagages</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ fontWeight: '700' }}>{v.perKm.toFixed(2).replace('.', ',')} €/km</Text>
                  <Text style={s.mut}>min. {v.min} €{v.minHub !== v.min ? ` · gares/aéroports ${v.minHub} €` : ''}</Text>
                </View>
              </View>
            ))}
            <Btn title="Fermer" style={{ marginTop: 16 }} onPress={() => setTarifs(false)} />
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

function Item({ icon, t, onPress, accent: gold }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [st.item, pressed && { backgroundColor: C.bg }]}>
      <Ionicons name={icon} size={22} color={gold ? C.pinkDark : C.ink} />
      <Text style={{ fontSize: 16, fontWeight: gold ? '800' : '500', color: gold ? C.pinkDark : C.ink }}>{t}</Text>
    </Pressable>
  );
}

const st = StyleSheet.create({
  fab: { position: 'absolute', width: 48, height: 48, borderRadius: 24, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...s.shadow },
  banner: { position: 'absolute', left: 16, right: 16, backgroundColor: C.black, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12, ...s.shadow },
  bannerIcon: { width: 36, height: 36, borderRadius: 18, backgroundColor: C.pink, alignItems: 'center', justifyContent: 'center' },
  sheet: { backgroundColor: '#fff', borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 18, paddingTop: 8, marginTop: -28, ...s.shadow },
  grab: { width: 40, height: 5, borderRadius: 3, backgroundColor: C.line, alignSelf: 'center', marginBottom: 12 },
  search: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.bg, borderRadius: 16, paddingHorizontal: 16, minHeight: 60 },
  nowChip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#fff', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7 },
  fromRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, paddingHorizontal: 4 },
  fav: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.bg, borderRadius: 24, paddingLeft: 6, paddingRight: 14, paddingVertical: 6, maxWidth: 240 },
  favIcon: { width: 30, height: 30, borderRadius: 15, backgroundColor: C.blue, alignItems: 'center', justifyContent: 'center' },
  routeCard: { flexDirection: 'row', gap: 12, backgroundColor: C.bg, borderRadius: 16, padding: 12 },
  veh: { flex: 1, borderRadius: 18, padding: 12, backgroundColor: C.bg, borderWidth: 2, borderColor: 'transparent', gap: 2 },
  seg: { flexDirection: 'row', backgroundColor: C.bg, borderRadius: 14, padding: 4, marginBottom: 10 },
  segItem: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', paddingVertical: 10, borderRadius: 11 },
  segOn: { backgroundColor: C.black },
  vehOn: { backgroundColor: C.black, borderColor: C.pink },
  whenBtn: { width: 96, borderRadius: 14, borderWidth: 1.5, borderColor: C.line, alignItems: 'center', justifyContent: 'center', gap: 2, padding: 6 },
  veil: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)' },
  drawer: { position: 'absolute', top: 0, bottom: 0, left: 0, width: '80%', backgroundColor: C.black },
  item: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingVertical: 15, paddingHorizontal: 22 },
  tarifSheet: { backgroundColor: '#fff', borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 20 },
});
