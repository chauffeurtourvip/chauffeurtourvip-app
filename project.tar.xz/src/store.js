import React, { createContext, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';
import { DRIVER_EMAIL } from './config';
import { getPushToken } from './push';
import { route } from './google';

const Ctx = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser] = useState(undefined); // undefined = chargement
  const [profile, setProfile] = useState(null);
  const [pickup, setPickup] = useState(null); // {address, lat, lng}
  const [dropoff, setDropoff] = useState(null);

  const [veh, setVeh] = useState('berline');
  const [when, setWhen] = useState(null);
  const [roundTrip, setRoundTrip] = useState(false);
  const [returnAt, setReturnAt] = useState(null); // null = dès que possible, sinon Date
  const [trip, setTrip] = useState(null); // {km, min, polyline} | {error} | 'loading'

  useEffect(() => onAuthStateChanged(auth, (u) => setUser(u || null)), []);

  // Calcule l'itinéraire réel dès que départ et arrivée sont connus
  useEffect(() => {
    if (!pickup || !dropoff) { setTrip(null); return; }
    let alive = true;
    setTrip('loading');
    route(pickup, dropoff)
      .then((r) => alive && setTrip(r))
      .catch((e) => alive && setTrip({ error: e.message }));
    return () => { alive = false; };
  }, [pickup?.lat, pickup?.lng, dropoff?.lat, dropoff?.lng]);

  useEffect(() => {
    if (!user) { setProfile(null); return; }
    const unsub = onSnapshot(doc(db, 'users', user.uid), (d) => setProfile(d.exists() ? d.data() : {}));
    // Enregistre le jeton de notification du téléphone
    getPushToken().then((token) => {
      if (!token) return;
      setDoc(doc(db, 'users', user.uid), { pushToken: token }, { merge: true }).catch(() => {});
      if (isDriverEmail(user.email)) setDoc(doc(db, 'settings', 'driver'), { pushToken: token }, { merge: true }).catch(() => {});
    });
    return unsub;
  }, [user?.uid]);

  const isDriver = !!user && isDriverEmail(user.email);
  return (
    <Ctx.Provider value={{ user, profile, isDriver, pickup, setPickup, dropoff, setDropoff, trip, veh, setVeh, when, setWhen, roundTrip, setRoundTrip, returnAt, setReturnAt }}>
      {children}
    </Ctx.Provider>
  );
}

function isDriverEmail(e) {
  return (e || '').toLowerCase() === DRIVER_EMAIL.toLowerCase();
}

export const useApp = () => useContext(Ctx);
